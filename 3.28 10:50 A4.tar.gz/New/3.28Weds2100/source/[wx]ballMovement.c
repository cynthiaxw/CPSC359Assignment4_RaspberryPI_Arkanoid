#include <stdio.h>
#include <stdlib.h>

//Function prototypes

extern void gameProcess();
extern void initBrick();
extern void	printSth();
extern int prePaddle[3];
extern int curPaddle[3];
extern int preBall[2];
extern int curBall[2];
extern int ballDirection[2];
extern char gameMap[27][22]; 
extern char brickMap[4][11];
extern int paddle_type;
extern int gameChoice;

extern int pressed_button;



void printSth(){
	//if(i!=0)printf("!!!!!%d\n", i);
	printf("!!!!!\n");
}

int calMapOffset(int x, int y){
    return (x-600)/32 + (y-80)/32 * 22;
}

//param: x,y
//return: 0 - not hit paddle
//return: 1 - hit left
//return: 2 - hit right
//return: 3 - hit middle
int hitPaddle(int x, int y){
    if(y < curPaddle[1] - 8 || x < curPaddle[0] - 8 || x > curPaddle[0] + curPaddle[2]){
        return 0;
    }
    if(x > curPaddle[0] && x < curPaddle[0] + 16){  //hit left
        ballDirection[0] = -3;
        ballDirection[1] = -3;
        return 1;
    }
    if(x < curPaddle[0] + curPaddle[2] && x > curPaddle[0] + curPaddle[2] - 48){    //hit right
        ballDirection[0] = 3;
        ballDirection[1] = -3;
        return 2;
    }
    else{   //hit middle
        if(ballDirection[0] > 0){//move right up
            ballDirection[0] = 2;
            ballDirection[1] = -3;
        }
        else{//move left up
            ballDirection[0] = -2;
            ballDirection[1] = -3;
        }
        return 3;
    }
}


typedef struct pos{
	int x, y;
} pos;


int min(int x, int y){
	return x<y ? x:y;
}

int max(int x, int y){
	return x>y ? x: y;
}

pos mapOffset(int x, int y){
	pos tmp;
	tmp.x = (y - 80)/32;
	tmp.y = (x - 600)/32;
	return tmp;
}

void hitBrick(int x, int y){	//x,y: ball centre	ball goes up
	pos tmp = mapOffset(x, y);	//map offset 27*22
	int dx = x - (600 + tmp.y * 32);
	int dy = y - (80 + tmp.x * 32);
	int hitv = gameMap[tmp.x][tmp.y];

	
	if(hitv >0 && hitv <4 ){	//hit bricks
			printf("gameMap[%d][%d] = %d\n",tmp.x, tmp.y, hitv);
		if(tmp.y%2 == 1){	//hit left half
			gameMap[tmp.x][tmp.y+1] -- ;
			drawRightBrick(tmp.x, tmp.y+1, gameMap[tmp.x][tmp.y+1]);
			dy = min(dy, 32 -dy);
			if(dx < dy && gameMap[tmp.x][tmp.y-1] == 0){	//hit left edge
				ballDirection[0] *= -1;
			}		
			else{	//hit up or down edge
				ballDirection[1] *= -1;
			}
		}
		else{	//hit right half
			gameMap[tmp.x][tmp.y-1] -- ;
			//draw the left part
			drawLeftBrick(tmp.x, tmp.y-1, gameMap[tmp.x][tmp.y-1]);
			
			dx = 32 - dx;
			dy = min(dy, 32 - dy);
			if(dx < dy && gameMap[tmp.x][tmp.y+1] == 0){	//hit right edge
				ballDirection[0] *= -1;
			}
			else{	//hit up or down edge
				ballDirection[1] *= -1;
			}
		}
		gameMap[tmp.x][tmp.y] -- ;
	}
	else return;
}


void hitBrickDown(int x, int y){	//x,y: ball centre	ball goes down
	//x+=8; y+=8;
	pos tmp = mapOffset(x, y);	//map offset 27*22
	int dx = x - (600 + tmp.y * 32);
	int dy = y - (80 + tmp.x * 32);
	int hitv = gameMap[tmp.x][tmp.y];

	
	if(hitv >0 && hitv <4 ){	//hit bricks
			printf("gameMap[%d][%d] = %d\n",tmp.x, tmp.y, hitv);
		if(tmp.y%2 == 1){	//hit left half
			gameMap[tmp.x][tmp.y+1] -- ;
			drawRightBrick(tmp.x, tmp.y+1, gameMap[tmp.x][tmp.y+1]);
			dy = min(dy, 32 -dy);
			if(dx < dy && gameMap[tmp.x][tmp.y-1] == 0){	//hit left edge
				ballDirection[0] *= -1;
			}		
			else{	//hit up or down edge
				ballDirection[1] *= -1;
			}
		}
		else{	//hit right half
			gameMap[tmp.x][tmp.y-1] -- ;
			//draw the left part
			drawLeftBrick(tmp.x, tmp.y-1, gameMap[tmp.x][tmp.y-1]);
			
			dx = 32 - dx;
			dy = min(dy, 32 - dy);
			if(dx < dy && gameMap[tmp.x][tmp.y+1] == 0){	//hit right edge
				ballDirection[0] *= -1;
			}
			else{	//hit up or down edge
				ballDirection[1] *= -1;
			}
		}
		gameMap[tmp.x][tmp.y] -- ;
	}
	else return;
}


void cleanBall(int x, int y){
	pos tmp = mapOffset(x, y);
	if(tmp.y % 2 == 1){	//left half		
		drawLeftBrick(tmp.x,tmp.y,gameMap[tmp.x][tmp.y]);
		drawRightBrick(tmp.x,tmp.y+1,gameMap[tmp.x][tmp.y+1]);
		drawLeftBrick(tmp.x+1,tmp.y,gameMap[tmp.x+1][tmp.y]);
		drawRightBrick(tmp.x+1,tmp.y+1,gameMap[tmp.x+1][tmp.y+1]);
	}
	else{	//right half
		drawRightBrick(tmp.x,tmp.y,gameMap[tmp.x][tmp.y]);
		drawLeftBrick(tmp.x,tmp.y+1,gameMap[tmp.x][tmp.y+1]);
		drawRightBrick(tmp.x+1,tmp.y,gameMap[tmp.x+1][tmp.y]);
		drawLeftBrick(tmp.x+1,tmp.y+1,gameMap[tmp.x+1][tmp.y+1]);
	}
}

void updateBall(){

//calculate the movement (direction)
    int tmp;
    tmp = hitPaddle(curBall[0],curBall[1]);
    
    if(tmp != 0){   //hit paddle
		printf("Hit paddle: %d, %d = %d\n",curBall[0],curBall[1], tmp);
        goto l_continue;
    }

	if(curBall[1] < 178){//hit up wall
		ballDirection[1] *= -1;
        goto l_continue;
	}
	if(curBall[0] < 634 || curBall[0] > 1238){//hit left or right wall
		ballDirection[0] *= -1;
		goto l_continue;
	}

	hitBrick(curBall[0], curBall[1]);
	cleanBall(curBall[0], curBall[1]);
	
//TODO: if value pack hidden behind the brick?

l_continue:
//Draw ball
	curBall[0] += ballDirection[0];
	curBall[1] += ballDirection[1];
	drawABall(curBall[0], curBall[1]);	
    preBall[0] = curBall[0];
    preBall[1] = curBall[1];

	//delayMicroseconds(1000);
}

void initBrick(){
	pos tmp;
	for(tmp.x = 6; tmp.x <9; tmp.x ++){
		for(tmp.y = 0; tmp.y<22; tmp.y++){
			if(tmp.y % 2 == 1){	//left half		
				drawLeftBrick(tmp.x,tmp.y,gameMap[tmp.x][tmp.y]);
			}
			else{	//right half
				drawRightBrick(tmp.x,tmp.y,gameMap[tmp.x][tmp.y]);
			}
		}
	}
}	

void wx_movePaddle(){
	int d1 = 5;
	int d2 = 10;
	if(pressed_button == 2){//left
		curPaddle[0] = max(632, curPaddle[0] - d1);
	}
	else if(pressed_button == 3){//right
		curPaddle[0] = min(1272 - curPaddle[2], curPaddle[0] + d1);
	}
	else if(pressed_button == 8){//left + A
		curPaddle[0] = max(632, curPaddle[0] - d2);
	}
	else if(pressed_button == 9){//right + A
		curPaddle[0] = min(1272 - curPaddle[2], curPaddle[0] + d2);
	}
	else{
		return;
	}
	if(paddle_type == 0){//32+64+32
		clean_paddle(prePaddle[0]);
		clean_paddle(prePaddle[0] + 32);
		clean_paddle(prePaddle[0] + 64);
		clean_paddle(prePaddle[0] + 96);
	}
	else{//32+96+32
		clean_paddle(prePaddle[0]);
		clean_paddle(prePaddle[0] + 32);
		clean_paddle(prePaddle[0] + 64);
		clean_paddle(prePaddle[0] + 96);
		clean_paddle(prePaddle[0] + 128);
	}

	
	prePaddle[0] = curPaddle[0];
	prePaddle[1] = curPaddle[1];
	prePaddle[2] = curPaddle[2];
}



void gameProcess(){
	
	if(pressed_button == 4){	//pause 	ST
		gameChoice = 2;
	}

	if(curBall[1] > 880){
		cleanBall(curBall[0], curBall[1]);
		curBall[0] = 936;
		curBall[1] = 840;
		curBall[0] = 936;
		curBall[1] = 840;
		ballDirection[0] = 3;
		ballDirection[1] = -3;
	}

    updateBall();
    if(pressed_button==10)printf("%d\n", pressed_button);
    movePaddle();
    //wx_movePaddle();
	draw_paddle(curPaddle[0], paddle_type);
}
