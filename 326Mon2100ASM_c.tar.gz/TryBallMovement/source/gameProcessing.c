#include <stdio.h>
#include <stdlib.h>

//Function prototypes
void drawABall(int x, int y);	//param: x,y - draw ball on (x,y)
void drawACell(int x, int y);	//param: x,y - draw floor on (x,y)
void drawABrick(int x, int y, int type);
void drawBrickOff(int x, int y, int type);

extern void gameProcessing();
extern int prePaddle[3];
extern int curPaddle[3];
extern int preBall[2];
extern int curBall[2];
extern int ballDirection[2];
extern char gameMap[27][22]; 
extern char brickMap[4][11];
extern int flg;



//clean previous ball position
//previous position(cell) draw floor 
void cleanPreBall(int preBall_x, int preBall_y){	
	//calculus last cell coordinates according to pre ball screen position
	int cell_x = ((preBall_x - 632)/32)*32 + 632;
	int cell_y = ((preBall_y - 176)/32)*32 + 176;
	drawACell(cell_x, cell_y);
	drawACell(cell_x, cell_y+32);
	if(cell_x + 32 < 1241)
	{
		drawACell(cell_x+32, cell_y);
		drawACell(cell_x+32, cell_y+32);
	}
	//printf("pre ball: %d, %d\n", preBall_x, preBall_y);
	//printf("cell: %d, %d\n", cell_x, cell_y);
}


int calMapOffset(int x, int y){
    return (x-600)/32 + (y-80)/32 * 22;
}

//param: x,y
//return: 0 - not hit paddle
//return: 1 - hit left
//return: 2 - hit right
//return: 3 - hit middle
int hitPaddle(int x, int y){
    if(y < curPaddle[1] - 31 || x < curPaddle[0] - 32 || x > curPaddle[0] + curPaddle[2]){
        return 0;
    }
    else{printf("!!!!!");
    if(x > curPaddle[0] && x < curPaddle[0] + 16){  //hit left
        ballDirection[0] = -3;
        ballDirection[1] = -3;
        return 1;
    }
    if(x < curPaddle[0] + curPaddle[2] && x > curPaddle[0] + curPaddle[2] - 48){    //hit right
        ballDirection[0] = 3;
        ballDirection[1] = -3;
        return 2;
    }
    else{   //hit middle
        if(ballDirection[0] > 0){//move right up
            ballDirection[0] = 2;
            ballDirection[1] = -3;
        }
        else{//move left up
            ballDirection[0] = -2;
            ballDirection[1] = -3;
        }
        return 3;
    }
}

}

typedef struct pos{
	int x, y;
} pos;


pos calBrickOffset(int x, int y){
	pos p;
	p.x = (y-240)/32;
	p.y = (x - 632)/64;
	return p;
}

void brickUpRight(int x, int y){
	pos tmp1 = calBrickOffset(x+32,y);
	int r1 = brickMap[tmp1.x][tmp1.y];
	if(r1 != 0){
		int d1 = x+32 - tmp1.y * 64 - 632;
		int d2 = y - tmp1.x * 32 - 240;
		if(d1 > d2){//up
			ballDirection[1] *= -1;
		}
		else{//right
			ballDirection[0] *= -1;
		}
		brickMap[tmp1.x][tmp1.y] --;
	}
	
	
}

void brickUpLeft(int x, int y){
	pos tmp1 = calBrickOffset(x,y);
	int r1 = brickMap[tmp1.x][tmp1.y];
	if(r1 != 0){
		int d1 = tmp1.y * 64 + 632 + 64 - x;
		int d2 = y - tmp1.x * 32 + 240 + 32 - y;
		if(d1 > d2){//up
			ballDirection[1] *= -1;
		}
		else{//left
			ballDirection[0] *= -1;
		}
		brickMap[tmp1.x][tmp1.y]--;
	}
}

void brickDownRight(int x, int y){
	pos tmp1 = calBrickOffset(x+32,y+32);
	int r1 = brickMap[tmp1.x][tmp1.y];
	if(r1 != 0){
		int d1 = x+32 - tmp1.y * 64 - 632;
		int d2 = y+32 - tmp1.x * 32 - 240;
		if(d1 > d2){//down
			ballDirection[1] *= -1;
		}
		else{//right
			ballDirection[0] *= -1;
		}
		brickMap[tmp1.x][tmp1.y]--;
	}
}

void brickDownLeft(int x, int y){
	pos tmp1 = calBrickOffset(x,y+32);
	int r1 = brickMap[tmp1.x][tmp1.y];
	if(r1 != 0){
		int d1 = tmp1.y * 64 + 632 + 64 - x;
		int d2 = tmp1.x * 32 - 240 + 23 - y;
		if(d1 > d2){//down
			ballDirection[1] *= -1;
		}
		else{//left
			ballDirection[0] *= -1;
		}
		brickMap[tmp1.x][tmp1.y]--;
	}
}

void inBrickArea(int x, int y){
	pos tmp = calBrickOffset(x, y);
	int r1 = brickMap[tmp.x][tmp.y];	//left up
	int r2 = brickMap[tmp.x][tmp.y+1];	//right up
	int r3 = brickMap[tmp.x+1][tmp.y];	//left down
	int r4 = brickMap[tmp.x+1][tmp.y+1];	//right down
	
	if(r1 == 0 && r2 == 0 && r3 == 0 && r4 == 0){
		printf("!!!!!\n");
		//goto l_brick_end;
		return;
	}
	
	if(ballDirection[0] > 0 && ballDirection[1] <0){	//up right
		brickUpRight(x, y);
	}
	else if(ballDirection[0] < 0 && ballDirection[1] <0){	//up left
		brickUpLeft(x,y);
	}
	else if(ballDirection[0] >0 && ballDirection[1] <0){	//down right
		brickDownRight(x,y);
	}
	else if(ballDirection[0] < 0 && ballDirection[1] >0){	//down left
		brickDownLeft(x,y);
	}
	
	r1 = brickMap[tmp.x][tmp.y];	//left up
	r2 = brickMap[tmp.x][tmp.y+1];	//right up
	r3 = brickMap[tmp.x+1][tmp.y];	//left down
	r4 = brickMap[tmp.x+1][tmp.y+1];	//right down
	drawBrickOff(tmp.x, tmp.y, r1);
	drawBrickOff(tmp.x, tmp.y+1, r2);
	drawBrickOff(tmp.x+1, tmp.y, r3);
	drawBrickOff(tmp.x+1, tmp.y+1, r4);
	/*
	if(r1 !=0){
		brickMap[tmp.x][tmp.y] --;
		r1 --;
		drawBrickOff(tmp.x, tmp.y, 1);
		if(ballDirection[0] < 0){		//go left
			ballDirection[0] *= -1;
		}
		printf("clean r1: %d, %d\n", tmp.x, tmp.y);
		printf("dir: %d, %d\n", ballDirection[0], ballDirection[1]);
		if(ballDirection[1] < 0){
			printf("!!!hit brick down side\n");
			printf("r2:%d\n",r2);
			ballDirection[1] *= -1;		//go up
			if(r2 != 0){	//hit brick down side
				brickMap[tmp.x][tmp.y+1] --;
				r2 --;
				drawBrickOff(tmp.x, tmp.y+1, r2);
				printf("hit brick down side\n");
				return;
			}
			
		}
		
			printf("r1: %d \n",r1);
			printf("tmp:%d, %d\n", tmp.x, tmp.y);
	}

	if(r2 != 0){
		//brickMap[tmp.x+1][tmp.y] --;	
		//r2--;
		drawBrickOff(tmp.x, tmp.y+1, r2);
		if(ballDirection[0] > 0){		//go right
			ballDirection[0] *= -1;
		}
		if(ballDirection[1] < 0){
			if(r1 == 0)ballDirection[1] *= -1;		//go up
		}
		printf("r2: %d \n",r2);
	}
	if(r3 != 0){
		//brickMap[tmp.x][tmp.y+1] --;	
		//r3--;
		drawBrickOff(tmp.x+1, tmp.y, r3);
		if(ballDirection[0] < 0){		//go left
			if(r1 == 0)ballDirection[0] *= -1;
		}
		if(ballDirection[1] > 0){
			ballDirection[1] *= -1;		//go down
		}
		printf("r3: %d \n",r3);
	}
	if(r4 != 0){
		//brickMap[tmp.x+1][tmp.y+1] --;
		//r4--;
		drawBrickOff(tmp.x+1, tmp.y+1, r4);
		if(ballDirection[0] > 0){		//go right
			if(r2 == 0)ballDirection[0] *= -1;
		}
		if(ballDirection[1] > 0){
			if(r3 == 0)ballDirection[1] *= -1;		//go down
		}
		printf("r4: %d \n",r4);
	}*/
	
}
int min(int x, int y){
	return x<y ? x:y;
}

pos mapOffset(int x, int y){
	pos result;
	result.x = (y - 80)/32;
	result.y = (x - 600)/32;

	return result;
}

void hitBrick(int x, int y){	//x,y: ball centre
	pos tmp = mapOffset(x, y);	//map offset 27*22
	int dx = x - (600 + tmp.y * 32);
	int dy = y - (80 + tmp.x * 32);
	int hitv = gameMap[tmp.x][tmp.y];

	
	if(hitv >0 && hitv <4 ){	//hit bricks
			printf("gameMap[%d][%d] = %d\n",tmp.x, tmp.y, hitv);
		if(tmp.y%2 == 1){	//hit left half
			gameMap[tmp.x][tmp.y+1] -- ;
			//drawRightBrick(tmp.x, tmp.y+1, gameMap[tmp.x][tmp.y+1]);
			dy = min(dy, 32 -dy);
			if(dx < dy){	//hit left edge
				ballDirection[0] *= -1;
			}		
			else{	//hit up or down edge
				ballDirection[1] *= -1;
			}
		}
		else{	//hit right half
			gameMap[tmp.x][tmp.y-1] -- ;
			//draw the left part
			drawLeftBrick(tmp.x, tmp.y-1, gameMap[tmp.x][tmp.y-1]);
			
			dx = 32 - dx;
			dy = min(dy, 32 - dy);
			if(dx < dy){	//hit right edge
				ballDirection[0] *= -1;
			}
			else{	//hit up or down edge
				ballDirection[1] *= -1;
			}
		}
		gameMap[tmp.x][tmp.y] -- ;
	}
	else return;
}

void cleanBall(int x, int y){
	pos tmp = mapOffset(x, y);
	if(tmp.y % 2 == 1){	//left half		
		drawLeftBrick(tmp.x,tmp.y,gameMap[tmp.x][tmp.y]);
		drawRightBrick(tmp.x,tmp.y+1,gameMap[tmp.x][tmp.y+1]);
		drawLeftBrick(tmp.x+1,tmp.y,gameMap[tmp.x+1][tmp.y]);
		drawRightBrick(tmp.x+1,tmp.y+1,gameMap[tmp.x+1][tmp.y+1]);
	}
	else{	//right half
		drawRightBrick(tmp.x,tmp.y,gameMap[tmp.x][tmp.y]);
		drawLeftBrick(tmp.x,tmp.y+1,gameMap[tmp.x][tmp.y+1]);
		drawRightBrick(tmp.x+1,tmp.y,gameMap[tmp.x+1][tmp.y]);
		drawLeftBrick(tmp.x+1,tmp.y+1,gameMap[tmp.x+1][tmp.y+1]);
	}
}

void updateBall(){

}


void updateBall1(){

//calculate the movement (direction)
    int tmp;
    tmp = hitPaddle(curBall[0],curBall[1]);


    if(tmp != 0){   //hit paddle
		printf("Hit paddle: %d, %d = %d\n",curBall[0],curBall[1], tmp);
        goto l_continue;
    }

	if(curBall[1] < 178){//hit up wall
		ballDirection[1] *= -1;
        goto l_continue;
	}
	if(curBall[0] < 634 || curBall[0] > 1238){//hit left or right wall
		ballDirection[0] *= -1;
		goto l_continue;
	}

	hitBrick(curBall[0], curBall[1]);
	cleanBall(curBall[0], curBall[1]);

//TODO: if value pack hidden behind the brick?

l_continue:
//Draw ball
	curBall[0] += ballDirection[0];
	curBall[1] += ballDirection[1];
/*
    if(preBall[0]>633 && preBall[0] < 1239 && preBall[1] > 240 && preBall[1] < 336){
		inBrickArea(preBall[0], preBall[1]);
	}
	else{
		cleanPreBall(preBall[0], preBall[1]);
	}
*/

	drawABall(curBall[0], curBall[1]);	
    preBall[0] = curBall[0];
    preBall[1] = curBall[1];

}




void gameProcessing(){
	/*if(!flg){
		for(int i=0; i<3; i++){
			for(int j=0; j<10; j++){
				drawBrickOff(i,j,brickMap[i][j]);
			}
		}
		flg = 1;
	}*/
	if(!flg){
		pos tmp;
		for(tmp.x = 0; tmp.x <27; tmp.x ++){
			for(tmp.y = 0; tmp.y<22; tmp.y++){
				if(tmp.y % 2 == 1){	//left half		
					drawLeftBrick(tmp.x,tmp.y,gameMap[tmp.x][tmp.y]);
				}
				else{	//right half
					drawRightBrick(tmp.x,tmp.y,gameMap[tmp.x][tmp.y]);
				}
			}
		}
		flg = 1;
	}
	//if(curBall[0]<632 || curBall[0] > 1240 || curBall[1]<176 || curBall[1] > 944){
	if(curBall[1] > 880){
		cleanBall(curBall[0], curBall[1]);
		curBall[0] = 936;
		curBall[1] = 816;
		curBall[0] = 936;
		curBall[1] = 816;
		ballDirection[0] = 3;
		ballDirection[1] = -3;
	}
	//if(curBall[1] > curPaddle[1]-5 ){//&& curBall[1] > 912){
	//printf("ball: %d, %d\n", curBall[0], curBall[1]);
	//printf("paddle: %d, %d\n", curPaddle[0], curPaddle[1]);}
	
	//printf("dir: %d, %d\n", ballDirection[0], ballDirection[1]);

    updateBall1();
	
}
